<?php $title = "000 search result";
include 'header-after-sigin.php'; ?>


<div class="product-inner-pages no-result-found mt-5">
    <section class="no-result-found-inner">
        <div class="container">
            <div class="row">
                <div class="offset-lg-3 col-md-12 col-lg-9">
                    <div class="row mb-5">
                        <div class="col-12">
                            <h3 class="result-found-txt mb-3">000 Results found for 'ABC Search'</h3>
                    <h2 class="no-product-found">No Products Found.</h2>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include 'footer.php'; ?>